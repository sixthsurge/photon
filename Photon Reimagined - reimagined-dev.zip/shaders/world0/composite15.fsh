#version 400 compatibility
#define WORLD_OVERWORLD
#define BLOOM_TILE_INDEX 3
#define fsh
#include "/program/c14_c18_bloom_upsample.fsh"

